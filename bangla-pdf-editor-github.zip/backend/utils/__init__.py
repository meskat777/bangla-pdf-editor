"""Utility modules for PDF processing"""
